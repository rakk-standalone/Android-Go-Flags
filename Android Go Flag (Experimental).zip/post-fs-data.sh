# Run Optimize_Habits.sh
/system/bin/sh $COMMON_DIR/Optimize_Habits.sh &